<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/bootstrap/js/popper.min.js"></script>

<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/js/waves.js"></script>
<!--Menu sidebar -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/js/sidebarmenu.js"></script>
<!--stickey kit -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/js/custom.min.js"></script>
<!-- ============================================================== -->
<!-- This page plugins -->
<!-- ============================================================== -->
<!--morris JavaScript -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/raphael/raphael-min.js"></script>
<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/morrisjs/morris.min.js"></script>
<!-- sparkline chart -->
<script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo e(URL::to('/public/admin/')); ?>/js/dashboard4.js"></script>
<!-- ============================================================== --><?php /**PATH D:\xampp\htdocs\micahha\resources\views/admin/includes/script.blade.php ENDPATH**/ ?>