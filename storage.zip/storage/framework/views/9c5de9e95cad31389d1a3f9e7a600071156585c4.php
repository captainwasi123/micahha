
<?php $__env->startSection('title', 'Pending | Members | Accommodation'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S#</th>
                                <th style="width:35px">Image</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Reg. at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td style="width:35px"><img src="<?php echo e(URL::to('/public/admin/')); ?>/assets/images/dp-placeholder.jpg" alt="user" class="thumbnail" /></td>
                                <td><a href="<?php echo e(route('admin.accommodation.members.profile')); ?>" target="_blank" data-toggle="tooltip" data-original-title="View Profile">Peter</a></td>
                                <td>12121212121</td>
                                <td><a href="mailto:peter@gmail.com">peter@gmail.com</a></td>
                                <td><p class="cut-text" title="Murree, Khyber Pakhtunkhwa, Pakistan">Murree, Khyber Pakhtunkhwa, Pakistan</p></td>
                                <td>29-May-2021 8:11 pm</td>
                                <td> 
                                	<a href="#" data-toggle="tooltip" data-original-title="Approve"> 
                                		<i class="fa fa-check text-success"></i> 
                                	</a>
                                	&nbsp;&nbsp;
                                    <a href="#" data-toggle="tooltip" data-original-title="Reject">
                                     	<i class="fa fa-close text-danger"></i> 
                                 	</a>
                             	</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td style="width:35px"><img src="<?php echo e(URL::to('/public/admin/')); ?>/assets/images/dp-placeholder.jpg" alt="user" class="thumbnail" /></td>
                                <td><a href="<?php echo e(route('admin.accommodation.members.profile')); ?>" target="_blank" data-toggle="tooltip" data-original-title="View Profile">Peter</a></td>
                                <td>12121212121</td>
                                <td><a href="mailto:peter@gmail.com">peter@gmail.com</a></td>
                                <td><p class="cut-text" title="Murree, Khyber Pakhtunkhwa, Pakistan">Murree, Khyber Pakhtunkhwa, Pakistan</p></td>
                                <td>29-May-2021 8:11 pm</td>
                                <td> 
                                    <a href="#" data-toggle="tooltip" data-original-title="Approve"> 
                                        <i class="fa fa-check text-success"></i> 
                                    </a>
                                    &nbsp;&nbsp;
                                    <a href="#" data-toggle="tooltip" data-original-title="Reject">
                                        <i class="fa fa-close text-danger"></i> 
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td style="width:35px"><img src="<?php echo e(URL::to('/public/admin/')); ?>/assets/images/dp-placeholder.jpg" alt="user" class="thumbnail" /></td>
                                <td><a href="<?php echo e(route('admin.accommodation.members.profile')); ?>" target="_blank" data-toggle="tooltip" data-original-title="View Profile">Peter</a></td>
                                <td>12121212121</td>
                                <td><a href="mailto:peter@gmail.com">peter@gmail.com</a></td>
                                <td><p class="cut-text" title="Murree, Khyber Pakhtunkhwa, Pakistan">Murree, Khyber Pakhtunkhwa, Pakistan</p></td>
                                <td>29-May-2021 8:11 pm</td>
                                <td> 
                                    <a href="#" data-toggle="tooltip" data-original-title="Approve"> 
                                        <i class="fa fa-check text-success"></i> 
                                    </a>
                                    &nbsp;&nbsp;
                                    <a href="#" data-toggle="tooltip" data-original-title="Reject">
                                        <i class="fa fa-close text-danger"></i> 
                                    </a>
                                </td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addScript'); ?>
	<!-- This is data table -->
    <script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/admin/accommodation/members/pending.blade.php ENDPATH**/ ?>