
<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>

<section class="pad-top-60 pad-bot-60">
     <div class="container">
        <div class="row">
           <div class="col-md-6 col-lg-6 col-12 col-sm-12">
              <div class="image-type1">
                 <img src="<?php echo e(URL::to('/public/website')); ?>/images/dressing-table.jpg">
              </div>
           </div>
           <div class="col-md-6 col-lg-6 col-12 col-sm-12">
              <div class="login-form">
                 <h3> Login </h3>
                  <?php if(session()->has('success')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session()->get('success')); ?>

                      </div>
                  <?php endif; ?>
                  <?php if(session()->has('error')): ?>
                      <div class="alert alert-danger">
                          <?php echo e(session()->get('error')); ?>

                      </div>
                  <?php endif; ?>
                 <form method="post">
                     <?php echo csrf_field(); ?>
                    <div class="form-field1">
                       <p> Email Address </p>
                       <input type="email" name="email" required="">
                    </div>
                    <div class="form-field1">
                       <p> Password </p>
                       <input type="password" name="password" required="">
                       <a href="" class="reset-password">  Reset Password </a>
                    </div>
                    <div class="form-field1 no-margin">
                       <input type="submit" class="submit-btn1" value="Login" name="" style="margin-top: -25px !important;">	
                    </div>
                 </form>
              </div>
              <div class="login-form">
                 <h3> Create An Account </h3>
                 <p class="para-1"> Receive exclusive access to sale previews. </p>
                 <p class="para-1"> Enjoy special offers throughout the year. </p>
                 <p class="para-1"> Easy order management and quick checkout. </p>
                 <a href="<?php echo e(route('user.register')); ?>" class="custom-btn1 m-t-20"> Create an account </a>
              </div>
           </div>
        </div>
     </div>
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/web/login.blade.php ENDPATH**/ ?>