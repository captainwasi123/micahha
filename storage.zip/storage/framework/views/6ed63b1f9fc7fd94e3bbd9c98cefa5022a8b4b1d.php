    <link rel="icon" href="<?php echo e(URL::to('/public/user/')); ?>/img/logo.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/css/bootstrap.min.css" />
    <!-- themefy CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/themefy_icon/themify-icons.css" />
    <!-- select2 CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/niceselect/css/nice-select.css" />
    <!-- owl carousel CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/owl_carousel/css/owl.carousel.css" />
    <!-- gijgo css -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/gijgo/gijgo.min.css" />
    <!-- font awesome CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/tagsinput/tagsinput.css" />

    <!-- date picker -->
     <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/datepicker/date-picker.css" />
     <!-- scrollabe  -->
     <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/scroll/scrollable.css" />
    <!-- datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/css/buttons.dataTables.min.css" />
    <!-- text editor css -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/text_editor/summernote-bs4.css" />
    <!-- morris css -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/morris/morris.css">
    <!-- metarial icon css -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/vendors/material_icon/material-icons.css" />

    <!-- menu css  -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/css/metisMenu.css">
    <!-- style CSS -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/css/style.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/css/dev.css" />
    <link rel="stylesheet" href="<?php echo e(URL::to('/public/user/')); ?>/css/colors/default.css" id="colorSkinCSS">
<?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/includes/style.blade.php ENDPATH**/ ?>