<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title> <?php echo $__env->yieldContent('title'); ?>  - Micahha </title>

      <?php echo $__env->make('web.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('addStyle'); ?>
   </head>
   <body>
      <!-- Header Starts Here -->
         <?php echo $__env->make('web.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Header Ends Here -->

      <?php echo $__env->yieldContent('content'); ?>

      <!-- Art Section Ends Here -->
      <!-- Footer Section Starts Here -->
         <?php echo $__env->make('web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Footer Section Ends Here -->
      <!-- Bootstrap Javascript -->
         <?php echo $__env->make('web.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <?php echo $__env->yieldContent('addScript'); ?>
   </body>
</html>
<?php /**PATH D:\xampp\htdocs\micahha\resources\views/web/includes/master.blade.php ENDPATH**/ ?>