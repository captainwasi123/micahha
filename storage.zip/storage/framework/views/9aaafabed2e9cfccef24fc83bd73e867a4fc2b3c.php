
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
                    <div class="white_card card_height_100 mb_30">
                        <div class="white_card_header">
                            <div class="box_header m-0">
                                <div class="main-title">
                                    <h3 class="m-0"><?php echo e($title); ?></h3>
                                    <?php if($errors->any()): ?>
                                        <div class="alert text-white bg-danger mb-0 mt-2" role="alert">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('success')): ?>
                                        <div class="alert text-white bg-success mb-0 mt-2" role="alert">
                                           <div class="alert-text"><b>Success!</b> <?php echo e(session()->get('success')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('error')): ?>
                                        <div class="alert text-white bg-danger mb-0 mt-2" role="alert">
                                           <div class="alert-text"><b>Alert!</b> <?php echo e(session()->get('error')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="white_card_body">
                            <div class="card-body">
                                <form method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="">Current Password</label>
                                            <input type="password" class="form-control" name="cur_password" required>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="">New Password</label>
                                            <input type="password" class="form-control" name="password" required>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="">Conform Password</label>
                                            <input type="password" class="form-control" name="password_confirmation" required>
                                        </div>
                                    </div>
                                    <br>
                                    <button type="submit" class="btn btn-primary">Change</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('landlord.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/settings/change_password.blade.php ENDPATH**/ ?>