<!-- Animate With CSS -->
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/public/website')); ?>/css/animate.css">
<!-- Slick Slider -->
<link href="<?php echo e(URL::to('/public/website')); ?>/css/slick.css" rel="stylesheet">
<link href="<?php echo e(URL::to('/public/website')); ?>/css/slick-theme.css" rel="stylesheet">
<!-- Bootstrap Grids -->
<link href="<?php echo e(URL::to('/public/website')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom Stylings -->
<link href="<?php echo e(URL::to('/public/website')); ?>/css/custom.css" rel="stylesheet">
<link href="<?php echo e(URL::to('/public/website')); ?>/css/dev.css" rel="stylesheet">
<!-- Font Awesome Icons -->
<link href="<?php echo e(URL::to('/public/website')); ?>/web-fonts-with-css/css/fontawesome-all.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<?php /**PATH D:\xampp\htdocs\micahha\resources\views/web/includes/style.blade.php ENDPATH**/ ?>