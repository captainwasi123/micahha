<footer class="footer">
    © 2021 MICAHHA. Developed By: <strong><a href="https://divsnpixel.com/" target="_blank">Divsnpixel</a></strong>
</footer><?php /**PATH D:\xampp\htdocs\micahha\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>