
<?php $__env->startSection('title', 'Rejected | Listings | Accommodation'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S#</th>
                                <th>Title</th>
                                <th>Address</th>
                                <th>Landlord</th>
                                <th>Price</th>
                                <th>Description</th>
                                <th>Property Type</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $s=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <?php 
                                    $address = empty($val->address) ? '' : $val->address->address.', '.$val->address->city.', '.$val->address->state.', '.$val->address->country->country.'. '.$val->address->post_code;
                                ?>
                                <tr>
                                    <td>1</td>
                                    <td><a href="<?php echo e(URL::to('/admin/accommodation/listing/details/'.base64_encode($val->id))); ?>" data-toggle="tooltip" data-original-title="View Details">Khawaja house</a></td>
                                    <td><p class="cut-text" title="Murree, Khyber Pakhtunkhwa, Pakistan">Murree, Khyber Pakhtunkhwa, Pakistan</p></td>
                                    <td><a href="<?php echo e(route('admin.accommodation.members.profile')); ?>" target="_blank" data-toggle="tooltip" data-original-title="View Profile">Wasi</a></td>
                                    <td>$50.0</td>
                                    <td>
                                    	<p class="cut-text" title="Situated at the most prime location of Kashmir point in Murree. Full secure, safe and peaceful surrounding . Majestic views from the apartment. All daily use amenities near by. All desi and continental food at the walking distance.">Situated at the most prime location of Kashmir point in Murree. Full secure, safe and peaceful surrounding . Majestic views from the apartment. All daily use amenities near by. All desi and continental food at the walking distance.</p>
                                    </td>
                                    <td>House</td>
                                    <td>29-May-2021 8:11 pm</td>
                                </tr>
                                <?php $s++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addScript'); ?>
	<!-- This is data table -->
    <script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/admin/accommodation/listings/rejected.blade.php ENDPATH**/ ?>