<!-- footer  -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/js/jquery-3.4.1.min.js"></script>
<!-- popper js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/js/popper.min.js"></script>
<!-- bootstarp js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/js/bootstrap.min.js"></script>
<!-- sidebar menu  -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/js/metisMenu.js"></script>
<!-- waypoints js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/count_up/jquery.waypoints.min.js"></script>
<!-- waypoints js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/chartlist/Chart.min.js"></script>
<!-- counterup js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/count_up/jquery.counterup.min.js"></script>

<!-- nice select -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/niceselect/js/jquery.nice-select.min.js"></script>
<!-- owl carousel -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/owl_carousel/js/owl.carousel.min.js"></script>

<!-- responsive table -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/dataTables.buttons.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/buttons.flash.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/jszip.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/pdfmake.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/vfs_fonts.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/buttons.html5.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datatable/js/buttons.print.min.js"></script>


<script src="<?php echo e(URL::to('/public/user/')); ?>/js/chart.min.js"></script>
<!-- progressbar js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/progressbar/jquery.barfiller.js"></script>
<!-- tag input -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/tagsinput/tagsinput.js"></script>
<!-- text editor js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/text_editor/summernote-bs4.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/am_chart/amcharts.js"></script>

<!-- scrollabe  -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/scroll/perfect-scrollbar.min.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/scroll/scrollable-custom.js"></script>


<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/chart_am/core.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/chart_am/charts.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/chart_am/animated.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/chart_am/kelly.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/chart_am/chart-custom.js"></script>
<!-- custom js -->
<script src="<?php echo e(URL::to('/public/user/')); ?>/js/custom.js"></script>
<?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/includes/script.blade.php ENDPATH**/ ?>