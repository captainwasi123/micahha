
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="white_card card_height_100 mb_30">
                        <div class="white_card_header">
                            <div class="box_header m-0">
                                <div class="main-title">
                                    <h3 class="m-0"><?php echo e($title); ?></h3>
                                    <?php if(session()->has('success')): ?>
                                        <div class="alert text-white bg-success mb-0 mt-2" role="alert">
                                        <div class="alert-text"><b>Success!</b> <?php echo e(session()->get('success')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('error')): ?>
                                        <div class="alert text-white bg-danger mb-0 mt-2" role="alert">
                                        <div class="alert-text"><b>Alert!</b> <?php echo e(session()->get('error')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="white_card_body">
                            <div class="QA_section">
                                <div class="white_box_tittle list_header">
                                    <div class="box_right d-flex lms_block">
                                        <div class="serach_field_2">
                                            <div class="search_inner">
                                                <!-- <form Active="#">
                                                    <div class="search_field">
                                                        <input type="text" placeholder="Search content here...">
                                                    </div>
                                                    <button type="submit"> <i class="ti-search"></i> </button>
                                                </form> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
        
                                <div class="QA_table mb_30">
                                    <!-- table-responsive -->
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>S#</th>
                                                <th>Image</th>
                                                <th style=" width: 100px; ">Title</th>
                                                <th>Address</th>
                                                <th>Price</th>
                                                <th>Description</th>
                                                <th>Property Type</th>
                                                <th>Timestamp</th>
                                                <th style=" width: 114px; ">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $listing_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                            <tr>
                                                
                                                <td><?php echo e(++$key); ?></td>
                                                <td>
                                                    <img src="<?php echo e(URL::to('/public/storage/listing/main/')); ?>/<?php echo e($listing->feature_img); ?>" alt="" width="30px">
                                                </td>
                                                <td><a href="<?php echo e(route('landlord.listing.details')); ?>" data-toggle="tooltip" data-original-title="View Details" title="<?php echo e($listing->title); ?>"><?php echo e(substr($listing->title,0,10)); ?>...</a></td>
                                                <td><p class="cut-text" title="<?php echo e($listing->address->address); ?>"><?php echo e(substr($listing->address->address,0,15)); ?>...</p></td>
                                                <td><?php echo e('$'.number_format($listing->price, 2)); ?></td>
                                                <td>
                                                    <p class="cut-text" title="<?php echo e($listing->description); ?>"><?php echo e(substr($listing->description,0,10)); ?>...</p>
                                                </td>
                                                <td><?php echo e(@$listing->type->name); ?></td>
                                                <td><?php echo e(date('d-M-Y h:i a', strtotime($listing->created_at))); ?></td>
                                                <td>
                                                    <a onclick="return confirm_click();"  href="<?php echo e(route('landlord.list.delete',base64_encode($listing->id))); ?>" data-toggle="tooltip" data-original-title="delete" class="btn btn-danger btn-sm">
                                                        <i class="fas fa-trash" style="color:#fff"></i> 
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                                        </tbody>
                                    </table>
                                    <?php echo e($listing_data->withQueryString()->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addScript'); ?>
	<!-- This is data table -->
    <script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>
      <script type="text/javascript">
function confirm_click()
{
return confirm("Are you sure ?");
}

</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('landlord.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/listing/rejected_listing.blade.php ENDPATH**/ ?>