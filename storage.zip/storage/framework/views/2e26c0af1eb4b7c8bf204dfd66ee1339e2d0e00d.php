<!-- Jquery Library -->
<script type="text/javascript" src="<?php echo e(URL::to('/public/website')); ?>/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>

<script src="<?php echo e(URL::to('/public/website')); ?>/js/bootstrap.min.js"> </script>
<script src="<?php echo e(URL::to('/public/website')); ?>/js/slick-slider.js"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
<script src="<?php echo e(URL::to('/public/website')); ?>/js/functions.js"> </script>
<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<?php /**PATH D:\xampp\htdocs\micahha\resources\views/web/includes/scripts.blade.php ENDPATH**/ ?>