<!-- Bootstrap Core CSS -->
<link href="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Morries chart CSS -->
<link href="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/morrisjs/morris.css" rel="stylesheet">


<!-- Custom CSS -->
<link href="<?php echo e(URL::to('/public/admin/')); ?>/css/style.css" rel="stylesheet">
<link href="<?php echo e(URL::to('/public/admin/')); ?>/css/dev.css" rel="stylesheet">
<!-- You can change the theme colors from here -->
<link href="<?php echo e(URL::to('/public/admin/')); ?>/css/colors/blue.css" id="theme" rel="stylesheet"><?php /**PATH D:\xampp\htdocs\micahha\resources\views/admin/includes/style.blade.php ENDPATH**/ ?>