
<?php $__env->startSection('title', 'Pending | Listings | Accommodation'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>S#</th>
                                <th>Title</th>
                                <th>Address</th>
                                <th>Landlord</th>
                                <th>Price</th>
                                <th>Description</th>
                                <th>Property Type</th>
                                <th>Timestamp</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $s=1; ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                <?php 
                                    $address = empty($val->address) ? '' : $val->address->address.', '.$val->address->city.', '.$val->address->state.', '.$val->address->country->country.'. '.$val->address->post_code;
                                ?>
                                <tr>
                                    <td><?php echo e($s); ?></td>
                                    <td><a href="<?php echo e(URL::to('/admin/accommodation/listing/details/'.base64_encode($val->id))); ?>" data-toggle="tooltip" data-original-title="View Details"><?php echo e($val->title); ?></a></td>
                                    <td>
                                        <p class="cut-text" title="<?php echo e($address); ?>">
                                            <?php echo e($address); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.accommodation.members.profile')); ?>" target="_blank" data-toggle="tooltip" data-original-title="View Profile">
                                            <?php echo e(empty($val->landlord) ? '' : $val->landlord->first_name); ?> 
                                            <?php echo e(empty($val->landlord) ? '' : $val->landlord->last_name); ?> 
                                        </a>
                                    </td>
                                    <td>
                                        <strong><?php echo e('$'.number_format($val->price, 2)); ?></strong> 
                                        <small><?php echo e($val->unit); ?></small>
                                    </td>
                                    <td>
                                    	<p class="cut-text" title="<?php echo e($val->description); ?>">
                                            <?php echo e($val->description); ?>   
                                        </p>
                                    </td>
                                    <td><?php echo e(empty($val->type) ? '' : $val->type->name); ?></td>
                                    <td><?php echo e(date('d-M-Y h:i a', strtotime($val->created_at))); ?></td>
                                    <td> 
                                    	<a href="#" data-toggle="tooltip" data-original-title="Approve"> 
                                    		<i class="fa fa-check text-success"></i> 
                                    	</a>
                                    	&nbsp;&nbsp;
                                        <a href="#" data-toggle="tooltip" data-original-title="Reject">
                                         	<i class="fa fa-close text-danger"></i> 
                                     	</a>
                                 	</td>
                                </tr>
                                <?php $s++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addScript'); ?>
	<!-- This is data table -->
    <script src="<?php echo e(URL::to('/public/admin/')); ?>/assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/admin/accommodation/listings/pending.blade.php ENDPATH**/ ?>