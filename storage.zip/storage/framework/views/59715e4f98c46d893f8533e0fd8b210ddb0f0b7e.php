<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
                    <div class="white_card card_height_100 mb_30">
                        <div class="white_card_header">
                            <div class="box_header m-0">
                                <div class="main-title">
                                    <h3 class="m-0"><?php echo e($title); ?></h3>
                                    <?php if(session()->has('success')): ?>
                                        <div class="alert text-white bg-success mb-0 mt-2" role="alert">
                                        <div class="alert-text"><b>Success!</b> <?php echo e(session()->get('success')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('error')): ?>
                                        <div class="alert text-white bg-danger mb-0 mt-2" role="alert">
                                        <div class="alert-text"><b>Alert!</b> <?php echo e(session()->get('error')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="white_card_body">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-8">
                                <form method="post" action="<?php echo e(route('landlord.reservation.save')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e(base64_encode(@$reservation->id)); ?>">
                                    <input type="hidden" name="status" value="<?php echo e(@$reservation->status); ?>">
                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <label for="">Listing</label>
                                            <select class="form-control" name="list_id" required>
                                                <option value="">select...</option>
                                                <?php $__currentLoopData = $listing_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->id); ?>"
                                                    <?php echo e($data->id == @$reservation->list_id ? 'selected' : ''); ?>

                                                    ><?php echo e($data->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="">User Name</label>
                                            <input type="text" class="form-control" value="<?php echo e(@$reservation->user_name); ?>" name="user_name" required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="">Phone Number</label>
                                            <input type="number" class="form-control" value="<?php echo e(@$reservation->ph_number); ?>" name="ph_number" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="">No of People</label>
                                            <input type="number" class="form-control" value="<?php echo e(@$reservation->no_of_people); ?>" name="no_of_people" required>
                                        </div>
                                        <div class="form-group col-md-8">
                                            <label for="">Check-In | Check-Out</label>
                                            <input type="text" class="form-control datepicker-here  digits" data-range="true" data-multiple-dates-separator="-" data-language="en" name="check_id_date" value="<?php echo e(@$reservation->check_in ? @$reservation->check_in."-".@$reservation->check_out : ' '); ?>" required>
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label for="">Customer Status</label>
                                            <select class="form-control" name="customer_status" required>
                                                <option value="0" <?php echo e(@$reservation->customer_status == 0 ? 'selected' : ''); ?>>Reserved</option>
                                                <option value="1" <?php echo e(@$reservation->customer_status == 1 ? 'selected' : ''); ?>>Checked-In</option>
                                                <option value="2" <?php echo e(@$reservation->customer_status == 3 ? 'selected' : ''); ?>>Checked-Out</option>
                                            </select>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </form>
                                   </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('addScript'); ?>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datepicker/datepicker.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datepicker/datepicker.en.js"></script>
<script src="<?php echo e(URL::to('/public/user/')); ?>/vendors/datepicker/datepicker.custom.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landlord.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/reservation/add.blade.php ENDPATH**/ ?>