<div class="footer_part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer_iner text-center">
                    <p>© 2021 MICAHHA. Developed By: <strong><a href="https://divsnpixel.com/" target="_blank">Divsnpixel</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
</section><?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/includes/footer.blade.php ENDPATH**/ ?>