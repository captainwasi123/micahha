
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
                    <div class="white_card card_height_100 mb_30">
                        <div class="white_card_header">
                            <div class="box_header m-0">
                                <div class="main-title">
                                    <h3 class="m-0"><?php echo e($title); ?></h3>
                                    <?php if(session()->has('success')): ?>
                                        <div class="alert text-white bg-success mb-0 mt-2" role="alert">
                                           <div class="alert-text"><b>Success!</b> <?php echo e(session()->get('success')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('error')): ?>
                                        <div class="alert text-white bg-danger mb-0 mt-2" role="alert">
                                           <div class="alert-text"><b>Alert!</b> <?php echo e(session()->get('error')); ?></div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="white_card_body">
                            <div class="card-body">
                                <form method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-row">
                                        <div class="form-group col-md-12">
                                            <div class="form-group mb-3 profileImageBlock">
                                                <img id="profileImage" class="profile_picture" src="<?php echo e(URL::to('/public/storage/users/'.Auth::user()->profile_image)); ?>" onerror="this.src = '<?php echo e(URL::to('/public/user/img/')); ?>/user.jpg';">
                                                <span class="ti-pencil-alt" id="profilePicIcon"></span>
                                                <input type="file" class="form-control" name="main_img" id="imageUpload" style="display: none;" accept=".jpeg , .jpg">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row mt-2">
                                        <div class="form-group col-md-4">
                                            <label for="">First Name</label>
                                            <input type="text" class="form-control" name="first_name" value="<?php echo e(Auth::user()->first_name); ?>" required>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="">Last Name</label>
                                            <input type="text" class="form-control" name="last_name" value="<?php echo e(Auth::user()->last_name); ?>" required>
                                        </div>
                                    </div>
                                    <div class="form-row mt-2">
                                        <div class="form-group col-md-5">
                                            <label for="">Email</label>
                                            <input type="email" class="form-control" disabled value="<?php echo e(Auth::user()->email); ?>" required>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="">Phone Number</label>
                                            <input type="text" class="form-control" name="phone" value="<?php echo e(Auth::user()->phone); ?>">
                                        </div>
                                    </div>
                                    <div class="form-row mt-2">
                                        <div class="form-group col-md-4">
                                            <label for="">Address</label>
                                            <input type="text" class="form-control" name="address" value="<?php echo e(Auth::user()->address); ?>">
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="">Country</label>
                                            <select class="form-control" name="country" required>
                                                <option value="">Select</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($val->id); ?>"
                                                        <?php echo e(Auth::user()->country_id == $val->id ? 'selected' : ''); ?>

                                                    ><?php echo e($val->country); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-row mt-2">
                                        <div class="form-group col-md-3">
                                            <label for="">Sunrub/City</label>
                                            <input type="text" class="form-control" name="city" value="<?php echo e(Auth::user()->city); ?>">
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label for="">State / Province</label>
                                            <input type="text" class="form-control" name="state" value="<?php echo e(Auth::user()->state); ?>">
                                        </div>
                                        <div class="form-group col-md-2">
                                            <label for="">Zip / Postal Code</label>
                                            <input type="text" class="form-control" name="post_code" value="<?php echo e(Auth::user()->post_code); ?>">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary mt-3">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('addScript'); ?>
<script type="text/javascript">
$(document).ready(function(){    
    $(document).on('click', '#profilePicIcon', function() {
        $("#imageUpload").click();
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var fileInput = document.getElementById('imageUpload'); 
            var filePath = fileInput.value; 
            var allowedExtensions =  
                            /(jpeg|jpg)$/i; 
                       
                    if (!allowedExtensions.exec(filePath)) { 
                        $('#file_error').append('File format is not supported, Please upload a file in JPEG or JPG format');
                        $('#submit').attr('disabled', true);
                        fileInput.value = ''; 
                        return false; 
                    }else{ 
                        $('#file_error').empty();
                        $('#submit').attr('disabled', false);
                    }


            var reader = new FileReader();
            
            reader.onload = function(e) {
              $('#profileImage').attr('src', e.target.result);
            }
            
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }


    $("#imageUpload").change(function() {
      readURL(this);
    });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('landlord.includes.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\micahha\resources\views/landlord/settings/profile_edit.blade.php ENDPATH**/ ?>