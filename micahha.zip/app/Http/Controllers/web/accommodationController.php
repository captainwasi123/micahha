<?php

namespace App\Http\Controllers\web;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\accommodation\listing;
use App\Models\accommodation\propertyType;

class accommodationController extends Controller
{
    //
    function index(){
        $data = array(
            'rendom_list' => listing::where('status',2)->inRandomOrder()->limit(3)->get(),
            'list_data' => listing::where('status',2)->latest()->limit(6)->get(),
            'property_type' => propertyType::get(),
          ); 
        return view('web.accommodation.index')->with($data);
    }

    function all(Request $request){
        
        $list = listing::where('status',2); 
        if ($request->filer){
            
            $property_type = $request->property_type ?? null;
            $price = explode('-', str_replace('$', '', $request->price));
            
            $list = $list->whereBetween('price',$price);
            $list = $list->when($property_type , function ($q, $property_type)
            {
                return $q->whereIN('property_type',$property_type);
            });

            if ($request->txtDateRange != null) {
                
                // $list = $list->where(function ($query) use ($date) {
                //     $query->whereNot('saturday_ot', '<=', $date);
                //     $query->whereNot('saturday_ct', '>=', $date);
                // });
            }
        }
        $list = $list->latest()->paginate(6);
             
        $data = array(
            'rendom_list' => listing::where('status',2)->inRandomOrder()->limit(3)->get(),
            'list_data' => $list,
            'property_type' => propertyType::get(),
        );
        return view('web.accommodation.all')->with($data);;
    }

    public function details(Request $request)
    {
        $list_id =  base64_decode($request->id);
        $data = array(
            'rendom_list' => listing::where('status',2)->where('id','!=',$list_id)->inRandomOrder()->limit(3)->get(),
            'list_data' => listing::where('status',2)->where('id',$list_id)->first(),
        );
        return view('web.accommodation.details')->with($data);
    }
}
