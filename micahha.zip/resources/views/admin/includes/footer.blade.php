<footer class="footer">
    © 2021 MICAHHA. Developed By: <strong><a href="https://divsnpixel.com/" target="_blank">Divsnpixel</a></strong>
</footer>