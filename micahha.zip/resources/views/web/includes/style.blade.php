<!-- Animate With CSS -->
<link rel="stylesheet" type="text/css" href="{{URL::to('/public/website')}}/css/animate.css">
<!-- Slick Slider -->
<link href="{{URL::to('/public/website')}}/css/slick.css" rel="stylesheet">
<link href="{{URL::to('/public/website')}}/css/slick-theme.css" rel="stylesheet">
<!-- Bootstrap Grids -->
<link href="{{URL::to('/public/website')}}/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom Stylings -->
<link href="{{URL::to('/public/website')}}/css/custom.css" rel="stylesheet">
<link href="{{URL::to('/public/website')}}/css/dev.css" rel="stylesheet">
<!-- Font Awesome Icons -->
<link href="{{URL::to('/public/website')}}/web-fonts-with-css/css/fontawesome-all.min.css" rel="stylesheet">