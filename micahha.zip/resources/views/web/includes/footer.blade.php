<footer>
   <div class="container">
      <div class="row">
         <div class="col-md-5 col-lg-5 col-sm-12 col-12">
            <div class="footer-form">
               <form>
                  <input type="email" placeholder="Email"  name="">
                  <input type="submit" value="Subscribe" name="">
               </form>
            </div>
         </div>
         <div class="col-md-7 col-lg-7 col-sm-12 col-12">
            <div class="footer-menu">
               <a href="" class="col-black"> Terms & Conditions </a>
               <a href="" class="col-black"> Privacy </a>
               <a href="" class="col-black"> Portrait Customization </a>
               <a href="" class="col-black"> Contact Us </a>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-12 col-lg-12 col-sm-12">
            <p class="col-black copyrights-text"> © All Rights Reserved. micahha  </p>
         </div>
      </div>
   </div>
</footer>
