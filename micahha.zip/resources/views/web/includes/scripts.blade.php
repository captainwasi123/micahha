<!-- Jquery Library -->
<script type="text/javascript" src="{{URL::to('/public/website')}}/js/jquery-3.2.1.min.js"></script>
<script src="{{URL::to('/public/website')}}/js/bootstrap.min.js"> </script>
<script src="{{URL::to('/public/website')}}/js/slick-slider.js"> </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
<script src="{{URL::to('/public/website')}}/js/functions.js"> </script>
<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">